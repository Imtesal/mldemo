import React from 'react'

export const About = () => {
    return (
        <div>
            This is About component.
            <p>
                    React.js is an open-source JavaScript library that is used
                    for building user interfaces specifically for single-page applications.
                    It’s used for handling the view layer for web and mobile apps. React
                    also allows us to create reusable UI components. React was first created
                    by Jordan Walke, a software engineer working for Facebook. React first deployed
                    on Facebook’s newsfeed in 2011 and on Instagram.com in 2012.React allows
                    developers to create large web applications that can change data, without
                    reloading the page. The main purpose of React is to be fast, scalable, and
                    simple. It works only on user interfaces in the application. This corresponds
                    to the view in the MVC template. It ca
              
            </p>
        </div>
    )
}

import React from 'react'

export const Footer = () => {

  return (
    <footer className='bg-dark text-light py-1'>
      <p className='text-center'>
        copyright &copy; globallogic.com
      </p>
    </footer>
  )
}
